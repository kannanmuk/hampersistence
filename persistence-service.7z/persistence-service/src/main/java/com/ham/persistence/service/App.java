package com.ham.persistence.service;

import java.sql.Connection;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.ham.persistence.util.SessionFactoryUtil;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	String str = "nfv.%s.config.imageUUID";
    	String child = "nfv.isrv.config.imageUUID";
    	String key = child.substring(0, child.indexOf("config"));
    	System.out.println(key);
    	boolean comp = child.matches(str);
    	System.out.println(comp);
    	
    	SessionFactory sessionFactory = SessionFactoryUtil.getSessionFactory();
    	Session session = sessionFactory.getCurrentSession();
    	
    	System.out.println(sessionFactory);
    	System.out.println(session);
    	
    	Connection con = session.connection();
    	
    	System.out.println(con);
    	
    }
}
