package com.ham.persistence.service.exception;

public class PersistenceCrudException extends PersistenceException {
    // private static Log log = LogFactory.getLog(DMMCRUDException.class);

    public PersistenceCrudException(PersistenceErrorCode code, Object[] params) {
        super(code, "CRUD", params);
    }

    public PersistenceCrudException(PersistenceErrorCode code, Object[] params, Throwable cause) {
        super(code, "CRUD", params, cause);
    }

   
    public String toString() {
        String s = getClass().getName();
        String message = getLocalizedMessage();
        return (message != null) ? (s + ":" + ",message=" + message)
                : (s + ":" + getFormattedErrorId());
    }

}
