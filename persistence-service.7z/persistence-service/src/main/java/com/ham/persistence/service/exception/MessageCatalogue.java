package com.ham.persistence.service.exception;

import java.text.MessageFormat;
import java.util.Locale;
import java.util.PropertyResourceBundle;

/*
 * MessageCatalogue Class to convert a key in the catalogue 
 * to appropriate locale specific string that can be displayed to 
 * user
 * @author Viji Balas
 */

public class MessageCatalogue {
    private static String baseName = "props.DMMException";
    private static PropertyResourceBundle propertyBundle = (PropertyResourceBundle) PropertyResourceBundle
            .getBundle(baseName);

    static {
        propertyBundle = (PropertyResourceBundle) PropertyResourceBundle
                .getBundle(baseName);
    }

    /**
     * Gets a string for the given key from the list of message catalogue files
     * 
     * @param key
     *            the key for the desired string.
     * @return matching string for the given key.
     * @exception MessageException
     *                if the passed key is null or if no matching entry is found
     *                in catalogue files.
     */
    public static String getString(String key) throws MessageException {
        if (!valid(key))
            throw new MessageException(
                    "Invalid Key. Please check DMMException.properties if "
                            + key + " exists!");

        return MessageFormat.format(propertyBundle.getString(key), null);

    }

    /**
     * Gets a string for the given key from the list of message catalogue files
     * and substitues the parameters with the passed values
     * 
     * @param key
     *            the key for the desired string.
     * @param parametersArray
     *            List of values to be substituted for parameters in the message
     *            for the given key.
     * @return matching string for the given key with the parameter values
     *         substituted
     * @exception MessageException
     *                if the passed key is null or if no matching entry is found
     *                in catalogue files.
     */
    public static String getString(String key, Object[] parametersArray)
            throws MessageException {
        if (!valid(key))
            throw new MessageException(
                    "Invalid Key. Please check DMMException.properties if "
                            + key + " exists!");
        return MessageFormat.format(propertyBundle.getString(key),
                parametersArray);
    }

    /**
     * Gets a string for the given key and given locale from the list of message
     * catalogue files
     * 
     * @param key
     *            the key for the desired string.
     * @param locale
     *            passed locale will override the system locale.
     * @return matching string for the given key.
     * @exception MessageException
     *                if the passed key is null or if no matching entry is found
     *                in catalogue files.
     */
    public static String getString(String key, Locale locale)
            throws MessageException {
        if (!valid(key))
            throw new MessageException(
                    "Invalid Key. Please check DMMException.properties if "
                            + key + " exists!");
        PropertyResourceBundle localeBundle = (PropertyResourceBundle) PropertyResourceBundle
                .getBundle(baseName, locale);
        return MessageFormat.format(localeBundle.getString(key), null);
    }

    /**
     * Gets a string for the given key and given locale from the list of message
     * catalogue files
     * 
     * @param key
     *            the key for the desired string and for the given locale - the
     *            system locale will be ignored.
     * @param locale
     *            passed locale will override the system locale.
     * @param parametersArray
     *            List of values to be substituted for parameters in the message
     *            for the given key and locale.
     * @exception MessageException
     *                if the passed key is null or if no matching entry is found
     *                in catalogue files.
     */
    public static String getString(String key, Locale locale,
            Object[] parametersArray) throws MessageException {
        if (!valid(key))
            throw new MessageException(
                    "Invalid Key. Please check DMMException.properties if "
                            + key + " exists!");
        PropertyResourceBundle localeBundle = (PropertyResourceBundle) PropertyResourceBundle
                .getBundle(baseName, locale);
        return MessageFormat.format(localeBundle.getString(key),
                parametersArray);
    }

    private static boolean valid(String key) {
        if ((key == null) || (propertyBundle.getString(key) == null))
            return false;

        return true;
    }

}
