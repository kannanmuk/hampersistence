package com.ham.persistence.service.exception;

public class MessageException extends Exception {

    private Exception rootException;

    /**
     * Constructor.
     * 
     * @param None
     *            .
     */
    public MessageException() {

    }

    /**
     * Constructor.
     * 
     * @param message
     *            Message about the possible root calue of this exception.
     */
    public MessageException(String message) {
        super(message);
    }

    /**
     * Constructor.
     * 
     * @param exception
     *            Root exception encountered for which this exception is being
     *            raised.
     */
    public MessageException(Exception exception) {
        this.rootException = exception;
    }

    /**
     * Constructor.
     * 
     * @param message
     *            Message about the possible root calue of this exception.
     * @param exception
     *            Root exception encountered for which this exception is being
     *            raised.
     */
    public MessageException(String message, Exception exception) {
        super(message);
        this.rootException = exception;
    }

    /**
     * To get the root cause exception for which this exception is being raised.
     * 
     * @param none
     *            .
     * @return exception root cause exception for which this exception is being
     *         raised.
     */
    public Exception getRootException() {
        return rootException;
    }
}