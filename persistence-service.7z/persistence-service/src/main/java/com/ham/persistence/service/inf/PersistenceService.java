package com.ham.persistence.service.inf;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.TransactionException;

import com.ham.persistence.service.exception.PersistenceException;

/**
 * Created by kmudadla on 9/24/2018.
 */
public interface PersistenceService {
	
	public static final Long PER_INSTANCE_AUTH_CONSTANT = -11111l;

	public Connection getConnection() throws Exception;

	public Connection getConnection(Session session) throws Exception;
	
	Session acquireHibernateSession();
	
	public PreparedStatement getPreparedStatmentConnection(String statmentString, Connection conn);
	
	public PreparedStatement getPreparedStatement(Statement stmt);

	void beginTransaction() throws Exception;

	void commitTransaction() throws Exception;

	List<?> getObjectsByNamedQuery(String name, Map<String, Object> parameters,
			int firstResult, int maxResults, Long domainId)
			throws TransactionException;

	List<?> getObjectsByNamedQuery(String name, Map<String, Object> parameters,
			int firstResult, int maxResults) throws TransactionException;

	List<?> getObjectsByNamedQuery(String name, Map<String, Object> parameters,
			int maxResults) throws TransactionException;

	List<?> getObjectsByNamedQuery(String name, Map<String, Object> parameters)
			throws TransactionException;

	Object getInstance(String className, Serializable instanceId,
			String shadowName) throws PersistenceException;
	

}
