package com.ham.persistence.service.exception;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PersistenceException extends Exception {

	
	 private static Log log = LogFactory.getLog(PersistenceException.class);
	    // ------------------------------------------------------------------------
	    // Variables
	    // ------------------------------------------------------------------------

	    /**
	     * The id identifying the error condition uniquely. Application programs can
	     * use this to take appropriate action for specific exceptions.
	     */
	    protected PersistenceErrorCode code;

	    protected String componentName;

	    protected Object[] params;

	    // Actual resulting message to be displayed to user with
	    // params and locale settings resolved.
	    protected String resultMessage;

	   
	    private PersistenceException() {
	        super();

	    }

	   
	    private PersistenceException(int errorId) {
	        super();

	    }

	    public PersistenceException(String message) {
	        super(message);
	        // this.errorId = ERR_DEFAULT;
	    }

	   
	    public PersistenceException(String message, Throwable cause) {
	        super(message, cause);
	        // this.errorId = ERR_DEFAULT;
	    }

	   
	    public PersistenceException(int errorId, String message) {
	        super(message);
	        // this.errorId = errorId;
	    }

	 
	    public PersistenceException(int errorId, String message, Throwable cause) {
	        super(message, cause);
	      
	    }

	  
	    public PersistenceException(int errorId, Throwable cause) {
	        super(cause);
	        // this.errorId = errorId;
	    }

	   

	    protected PersistenceException(PersistenceErrorCode code, String componentName,
	            Object[] params) {
	        this.initAttributes(code, componentName, params, null);
	    }

	 
	    private void initAttributes(PersistenceErrorCode code, String componentName,
	            Object[] params, Throwable cause) {
	        // if (cause != null)
	        // super.setStackTrace(cause.getStackTrace());

	        this.code = code;
	        this.componentName = componentName;
	        this.params = params;
	        String key = null;
	        key = code.toString();
	        try {
	            this.resultMessage = MessageCatalogue.getString(key, params);
	            if ((resultMessage == null)
	                    || (resultMessage.trim().equalsIgnoreCase(""))) {
	                log.error("code " + code
	                        + " does not have a match in PersistenceException.properties");
	            }
	        } catch (Throwable t) {
	            log.error("Error looking up " + key + " in catalogue");
	            t.printStackTrace();
	        }

	    }

	   	    protected PersistenceException(PersistenceErrorCode code, String componentName,
	            Object[] params, Throwable cause) {
	        super(cause);
	        this.initAttributes(code, componentName, params, cause);
	    }

	  
	    public int getErrorId() {
	        return this.code.ordinal();
	    }

	   
	    public String getComponentName() {
	        return this.componentName;
	    }

	 
	    public String toString() {
	        return getMessage();
	    }

	    public String getFormattedErrorId() {
	        return "errorId=" + this.getErrorId() + ",componentName="
	                + this.componentName;
	    }

	    public String getMessage() {
	        if (this.resultMessage != null)
	            return getFormattedErrorId() + " " + this.resultMessage;
	        return super.getMessage();
	    }

	    public String getLocalizedMessage() {
	        return getMessage();
	    }

	
}
