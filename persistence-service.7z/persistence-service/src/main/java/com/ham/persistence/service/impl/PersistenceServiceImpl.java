package com.ham.persistence.service.impl;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.JDBCException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.TransactionException;
import org.hibernate.impl.FilterImpl;
import org.hibernate.util.ReflectHelper;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.DefaultTransactionDefinition;

import com.ham.persistence.service.exception.PersistenceCrudException;
import com.ham.persistence.service.exception.PersistenceErrorCode;
import com.ham.persistence.service.exception.PersistenceException;
import com.ham.persistence.service.inf.PersistenceFactory;
import com.ham.persistence.service.inf.PersistenceService;

public class PersistenceServiceImpl implements PersistenceService {

	private static Log log = LogFactory.getLog(PersistenceException.class);

	private static boolean isAuth;

	private PersistenceFactory persistenceFactory;

	private PlatformTransactionManager transactionManager;

	private Map<Long, LinkedList<TransactionStatus>> h = Collections
			.synchronizedMap(new HashMap<Long, LinkedList<TransactionStatus>>());

	private String IS_AUTHORITATIVE;

	private Properties properties;

	protected boolean isAutoCommit = false;
	protected Transaction implicitTx = null;

	public void setPersistenceFactory(PersistenceFactory factory) {
		persistenceFactory = factory;
	}

	@SuppressWarnings("deprecation")
	@Override
	public Connection getConnection() throws Exception {
		Session currentSession = acquireHibernateSession();
		Connection connection = null;
		try {
			connection = currentSession.connection();
		} catch (Exception e) {
			System.out
					.println("Exception during establishing a connection" + e);
		}
		return connection;
	}

	@Override
	public Connection getConnection(Session session) throws Exception {
		// TODO Auto-generated method stub
		return session.connection();
	}

	@Override
	public Session acquireHibernateSession() {

		SessionFactory sf = persistenceFactory.getSessionFactory();

		return sf.getCurrentSession();
	}

	@Override
	public PreparedStatement getPreparedStatmentConnection(
			String statmentString, Connection conn) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PreparedStatement getPreparedStatement(Statement stmt) {
		// TODO Auto-generated method stub
		return null;
	}

	public void setTransactionManager(
			PlatformTransactionManager transactionManager) {
		this.transactionManager = transactionManager;
	}

	@Override
	public void beginTransaction() throws Exception {

		LinkedList<TransactionStatus> txns = h.get(Thread.currentThread()
				.getId());
		if (txns == null) {
			txns = new LinkedList<TransactionStatus>();
			h.put(Thread.currentThread().getId(), txns);
		}
		TransactionStatus transactionStatus = transactionManager
				.getTransaction(new DefaultTransactionDefinition());
		txns.addFirst(transactionStatus);

	}

	@Override
	public void commitTransaction() throws Exception {
		LinkedList<TransactionStatus> txns = h.get(Thread.currentThread()
				.getId());
		transactionManager.commit(txns.removeFirst());
		if (txns.isEmpty()) {
			// If it reaches here then the last commit is successful and hence
			// remove the transaction.
			h.remove(Thread.currentThread().getId());
		}
	}

	public List executeQuery(Session currentSession, String queryString,
			Map namedParam, String queryLanguage) throws PersistenceException {
		return executeQuery(currentSession, queryString, namedParam,
				queryLanguage, 0, 0);

	}

	public List executeQuery(Session currentSession, String queryString,
			String queryLanguage) throws PersistenceException {
		return executeQuery(currentSession, queryString, null, queryLanguage,
				0, 0);

	}

	public List executeQuery(Session currentSession, String queryString)
			throws PersistenceException {
		return executeQuery(currentSession, queryString, null, "SQL", 0, 0);

	}

	public List executeQuery(Session currentSession, String queryString,
			Map namedParam, String queryLanguage, int startRow, int pageSize)
			throws PersistenceException {
		List list = null;
		try {
			long startTime = System.currentTimeMillis();

			if (queryString == null || queryString.isEmpty()) {
				log.error("Input queryString cannot be null or empty");
				throw new PersistenceCrudException(
						PersistenceErrorCode.CRUD_QUERYSTRING_NULLOREMPTY, null);
			}

			if (queryLanguage == null || queryLanguage.isEmpty()) {
				log.error("Input queryLanguage cannot be null or empty");
				throw new PersistenceCrudException(
						PersistenceErrorCode.CRUD_QUERYLANG_NULLOREMPTY, null);
			}

			// non-auth
			Query qry = null;
			if (queryLanguage.equals("EJBQL"))
				qry = currentSession.createQuery(queryString);
			else if (queryLanguage.equals("NamedQuery"))
				qry = currentSession.getNamedQuery(queryString);
			else if (queryLanguage.equals("SQL")) {
				validateSQLSelect(queryString);
				qry = currentSession.createSQLQuery(queryString);
			} else {
				log.error("Unsupported Query Language. Expected value: EJBQL,NamedQuery,SQL");
				throw new PersistenceCrudException(
						PersistenceErrorCode.CRUD_UNSUPPORTED_QUERY_LANGUAGE,
						null);
			}

			// Code Review Chitra: Can we not do the validation check before we
			// create Queries ?
			if (startRow < 0) {
				Object[] params = { new Integer(startRow) };
				// log.error("Invalid startRow = " + startRow);
				throw new PersistenceCrudException(
						PersistenceErrorCode.CRUD_INVALID_STARTROW, params);
			}

			if (pageSize < 0) {
				Object[] params = { new Integer(pageSize) };
				// log.error("Invalid pageSize = " + pageSize);
				throw new PersistenceCrudException(
						PersistenceErrorCode.CRUD_INVALID_PAGESIZE, params);
			}

			if (namedParam != null) {
				Set keyset = namedParam.keySet();
				Iterator it = keyset.iterator();
				while (it.hasNext()) {
					String key = (String) it.next();
					// Follwing line commented by snallaga
					// qry.setParameter(key, namedParam.get(key));

					// Followingi if-else code added by snallaga
					// to enable binding of Collections to EJBQL
					Object keyValue = namedParam.get(key);
					if (keyValue instanceof Collection) {
						qry.setParameterList(key, (Collection) keyValue);
					} else if (keyValue instanceof Object[]) {
						qry.setParameterList(key, (Object[]) keyValue);
					} else {
						qry.setParameter(key, keyValue);
					}
				}
			}
			// adding pageSize and startRow
			if ((pageSize != Integer.MAX_VALUE)
					&& (!(pageSize == 0 && startRow == 0)))
				list = qry.setFirstResult(startRow).setMaxResults(pageSize)
						.list();
			else
				list = qry.list();
			long endTime = System.currentTimeMillis();

			if (log.isDebugEnabled())
				log.debug("Time taken to execute Paging Query:"
						+ (endTime - startTime) + " ms");
		} catch (HibernateException hibEx) {
			String hibExMsg = hibEx.getMessage();
			if (hibExMsg != null && hibExMsg.contains("Filter [dataFilter]"))
				;
			{
				if (currentSession != null) {
					String threadName = Thread.currentThread().getName();
					FilterImpl f = (FilterImpl) currentSession
							.getEnabledFilter("dataFilter");
					boolean isFilterEnabled = f != null;
					log.info("Filter [dataFilter] -" + threadName
							+ "- isFilterEnabled = " + isFilterEnabled);
					if (isFilterEnabled) {
						Collection filterParam = (Collection) f
								.getParameter("domainIds");
						if (filterParam != null) {
							for (Iterator itr = filterParam.iterator(); itr
									.hasNext();) {
								log.info("Filter [dataFilter] -"
										+ threadName
										+ "- Exception occurred in persistence class in executeQuery - "
										+ "Filter [dataFilter] - domainIds "
										+ itr.next());
							}
						} else {
							log.info("Filter [dataFilter] -" + threadName
									+ "- filterParam is null");
						}
					} else {
						log.info("Filter [dataFilter] -" + threadName
								+ "- isFilterEnabled=  " + isFilterEnabled);
					}
					Exception e = new Exception();
					e.printStackTrace();
					log.info("Filter [dataFilter] - "
							+ Thread.currentThread().getName());
				}
			}
			Object[] params = { hibEx.getMessage() };
			throw new PersistenceCrudException(
					PersistenceErrorCode.CRUD_EXECQUERY_FAILED, params, hibEx);
		} catch (PersistenceException dmmEx) {
		
			Object[] params = { dmmEx.getMessage() };
			throw new PersistenceCrudException(
					PersistenceErrorCode.CRUD_EXECQUERY_FAILED, params, dmmEx);
		} catch (Exception ex) {
			// log.error("executeQuery failed",ex);
			Object[] params = { ex.getMessage() };
			throw new PersistenceCrudException(
					PersistenceErrorCode.CRUD_EXECQUERY_FAILED, params, ex);
		}
		return list;
	}

	private void validateSQLSelect(String queryString)
			throws PersistenceException {
		String trimmedQuery = queryString.trim();
		String sqlOperation = trimmedQuery.substring(0,
				trimmedQuery.indexOf(" "));
		if (sqlOperation.equalsIgnoreCase("delete")
				|| sqlOperation.equalsIgnoreCase("insert")
				|| sqlOperation.equalsIgnoreCase("update")) {

			Object[] params = { new String(sqlOperation) };
			throw new PersistenceCrudException(
					PersistenceErrorCode.CRUD_DML_NOT_VALID, params);
		}
	}

	public void deleteInstance(String className, Serializable instanceId)
			throws PersistenceException {
		deleteInstance(className, instanceId, null);
	}

	public void deleteInstance(String className, Serializable instanceId,
			String shadowName) throws PersistenceException {
		Session currentSession = acquireHibernateSession();
		try {

			Object targetObj = currentSession.get(
					ReflectHelper.classForName(className), instanceId);
			if (targetObj == null) {
				log.error("Instance does not exist!");
				throw new PersistenceCrudException(
						PersistenceErrorCode.CRUD_INSTANCE_DOES_NOT_EXIST, null);
			}

			currentSession.delete(targetObj);
			if (isAutoCommit)
				implicitTx.commit();

		} catch (Exception ex) {
			handleException(ex, "Instance does not exist!");
		} finally {
			if (isAutoCommit) {
				isAutoCommit = false;
				currentSession.close();
			}
		}
		return;
	}

	public void deleteInstance(Object aInstance) throws PersistenceException {
		deleteInstance((String) aInstance, null);
	}

	public static boolean isAuth() {
		return isAuth;
	}

	public boolean isAuthoritative() {

		if ((properties.getProperty(IS_AUTHORITATIVE) != null)
				&& (properties.getProperty(IS_AUTHORITATIVE).trim()
						.equalsIgnoreCase("true")))
			return true;
		else
			return false;
	}

	public Object getInstance(String className, Serializable instanceId)
			throws PersistenceException {
		return getInstance(className, instanceId, null);
	}

	@Override
	public Object getInstance(String className, Serializable instanceId,
			String shadowName) throws PersistenceException {
		Object retObj = null;
		Session currentSession = acquireHibernateSession();
		try {
			retObj = currentSession.get(ReflectHelper.classForName(className),
					instanceId);

			if (isAutoCommit)
				implicitTx.commit();

		} catch (Exception ex) {
			handleException(ex, "getInstance Failed");
		} finally {
			if (isAutoCommit) {
				isAutoCommit = false;
				currentSession.close();
			}
		}
		return retObj;
	}

	protected void handleException(Exception ex, String errorMessage)
			throws PersistenceException {
		if (isAutoCommit && implicitTx != null)
			implicitTx.rollback();
		if (log.isInfoEnabled() || log.isDebugEnabled())
			log.error(errorMessage, ex);
		if (PersistenceException.class.isAssignableFrom(ex.getClass()))
			throw (PersistenceException) ex;
		Object[] params = { errorMessage };

		if (ex.getMessage() != null
				&& ex.getMessage().compareTo("No Auth") == 0) {
			throw new PersistenceCrudException(
					PersistenceErrorCode.CRUD_NO_AUTH, params, ex);
		} else if (ex instanceof JDBCException) {
			throw new JDBCException(errorMessage, null);
		} else {
			throw new PersistenceCrudException(PersistenceErrorCode.CRUD_ERROR,
					params, ex);
		}
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = TransactionException.class)
	public List<?> getObjectsByNamedQuery(String name,
			Map<String, Object> parameters) throws TransactionException {
		return getObjectsByNamedQuery(name, parameters, 0, -1);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = TransactionException.class)
	public List<?> getObjectsByNamedQuery(String name,
			Map<String, Object> parameters, int maxResults)
			throws TransactionException {
		return getObjectsByNamedQuery(name, parameters, 0, maxResults);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = TransactionException.class)
	public List<?> getObjectsByNamedQuery(String name,
			Map<String, Object> parameters, int firstResult, int maxResults)
			throws TransactionException {
		return getObjectsByNamedQuery(name, parameters, firstResult,
				maxResults, null);
	}

	@Override
	@Transactional(propagation = Propagation.SUPPORTS, rollbackFor = TransactionException.class)
	public List<?> getObjectsByNamedQuery(String name,
			Map<String, Object> parameters, int firstResult, int maxResults,
			Long domainId) throws TransactionException {
		try {
			Query query = acquireHibernateSession().getNamedQuery(name);
			bindParameters(query, parameters, domainId);
			if (firstResult > 0) {
				query.setFirstResult(firstResult);
			}
			if (maxResults >= 0) {
				query.setMaxResults(maxResults);
			}

			// This is incredible, but even though this could
			// be an SQL query, it is still instantiated through the
			// Session. So, the result will be ordinary persistent
			// objects, even for a raw SQL query.
			return query.list();
		} catch (HibernateException ex) {
			log.error(ex);
			throw new HibernateException(ex);
		}
	}

	private void bindParameters(Query query, Map<String, Object> parameters,
			Long domainId) {
		// ANISUR DOMAIN
		if (parameters == null) {
			parameters = new HashMap<String, Object>();
		}
		if (domainId != null) {
			parameters.put("domainId", domainId);
		}
		for (Map.Entry<String, Object> entry : parameters.entrySet()) {
			String name = entry.getKey();
			Object value = entry.getValue();
			if (value != null) {
				if (value instanceof Collection<?>) {
					query.setParameterList(name, (Collection<?>) value);
				} else {
					query.setParameter(name, value);
				}
			}
		}
	}

}
