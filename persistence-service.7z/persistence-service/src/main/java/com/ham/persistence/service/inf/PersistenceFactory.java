package com.ham.persistence.service.inf;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import javax.persistence.EntityManagerFactory;

/**
 * Created by kmudadla on 9/24/2018.
 */
public interface PersistenceFactory {
	

	public SessionFactory getSessionFactory();

	public Session getHibernateCurrentSession();

	public Session openHibernateSession();

	public Session openHibernateSession(Session session);

	public void closeSession(Session session);

	public EntityManagerFactory getEntityManagerFactory();

}
