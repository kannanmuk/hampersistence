package com.ham.persistence.service.impl;



import javax.persistence.EntityManagerFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;


import com.ham.persistence.service.inf.PersistenceFactory;

public class PersistenceFactoryImpl implements PersistenceFactory, ApplicationContextAware {
    public static final String BACKGROUND_SESSION_FACTORY_CREATOR_THREAD_NAME = "real-session-factory-creator";
   
    
    

    private static SessionFactory sessionFactory;
    
	private ApplicationContext ctx;

    public void setApplicationContext(ApplicationContext _ctx) {
        ctx = _ctx;
    }
	
	 
	@Override
	public SessionFactory getSessionFactory() {
		sessionFactory = new Configuration().configure().buildSessionFactory();
		
		return sessionFactory;
	}
	@Override
	public Session getHibernateCurrentSession() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Session openHibernateSession() {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public Session openHibernateSession(Session session) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public void closeSession(Session session) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public EntityManagerFactory getEntityManagerFactory() {
		// TODO Auto-generated method stub
		return null;
	}
   
}